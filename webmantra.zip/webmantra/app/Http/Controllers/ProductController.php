<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use PayPalCheckoutSdk\Core\PayPalHttpClient;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersCaptureRequest;
use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalCheckoutSdk\Core\ProductionEnvironment;
use Illuminate\Support\Facades\Session;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();
        return view('product', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function cart()
    {
        return view('cart');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addToCart($id)
    {
        $product = Product::findOrFail($id);
          
        $cart = session()->get('cart', []);
  
        if(isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "name" => $product->name,
                "quantity" => 1,
                "price" => $product->price,
                "image" => $product->image
            ];
        }
          
        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Product added to cart successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
 

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        if($request->id && $request->quantity){
            $cart = session()->get('cart');
            $cart[$request->id]["quantity"] = $request->quantity;
            session()->put('cart', $cart);
            session()->flash('success', 'Cart updated successfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function remove(Request $request)
    {
        if($request->id) {
            $cart = session()->get('cart');
            if(isset($cart[$request->id])) {
                unset($cart[$request->id]);
                session()->put('cart', $cart);
            }
            session()->flash('success', 'Product removed successfully');
        }
    }


    public function checkout(Request $request)
    {
        $request->validate([
            'name' => 'sometimes|required|max:150',
            'mobile' => 'sometimes|required|max:25',
            'address' => 'required',
            'email' => 'required|email|max:100',
        ]);
        $input = $request->all();
        $cart = session()->get('cart');

        if(isset( $cart)) {
        
            if($input['payment_method'] == 'paypal') {
                $payment_mode = 'PAYPAL';
            }

            if(isset($input['payment_method'])) {
                if($input['payment_method'] == 'paypal') {
                    $item_details_arr = array(
                        'currencyCode' => 'USD',
                        'itemValue'    => $input['payment_total'],
                    );
    
                    $billing_address_arr = array(
                        "Name"    => $input['name'],
                        "address" => $input['address'],
                        "email" => $input['email'],
                        "mobile" => $input['mobile'],
                    );
    
    
                    $redirect_urls_arr = array(
                        "return" => url('/order-payment-success'),
                        "cancel" => url('/order-payment-cancel')
                    );
                   // return $redirect_urls_arr;

                    $paypal_checkout_url = $this->paypal_payment($item_details_arr, $redirect_urls_arr, $billing_address_arr);
                    return redirect()->away($paypal_checkout_url);
                }
            }

            return redirect()->route('success.page')->with('success', 'Billing details submitted successfully!');
        }
        return redirect()->route('cart')->with('success', 'Add few items in your cart');;


    }


    public function paypal_payment($item_details_arr, $redirect_urls_arr, $billing_address_arr)
    {
    

        if ($item_details_arr['currencyCode'] == 'USD') {
            $mode         = config("app.paypal_mode_us");
            $clientId     = config("app.paypal_client_id_us") ?: "<<PAYPAL-CLIENT-ID>>";
            $clientSecret = config("app.paypal_client_secret_us") ?: "<<PAYPAL-CLIENT-SECRET>>";
        }

        if(isset($mode) && $mode == 'live') {
            $environment = new ProductionEnvironment($clientId, $clientSecret);
        } else {
            $environment = new SandboxEnvironment($clientId, $clientSecret);
        }
        
        $request = new OrdersCreateRequest();
        $request->headers["prefer"] = "return=representation";
       
        $request->body = array(
            'intent' => 'CAPTURE',
            'application_context' =>
                array(
                    'return_url' => $redirect_urls_arr['return'],
                    'cancel_url' => $redirect_urls_arr['cancel'],
                    'brand_name' => 'Mantra-web',
                    'locale' => 'en-US',
                    'landing_page' => 'BILLING',
                    'shipping_preference' => 'SET_PROVIDED_ADDRESS',
                    'user_action' => 'PAY_NOW',
                ),
            'payer'=> array(
                'email_address' => $billing_address_arr['email'],
                'name' => array(
                    'name' => $billing_address_arr['Name']
                ),
              
            ),
            'payment_method' =>
                array(
                    'payee_preferred' => 'IMMEDIATE_PAYMENT_REQUIRED'
                ),
            'purchase_units' =>
                array(
                    0 =>
                        array(
                            'description' => $billing_address_arr['Name'],
                            'amount' =>
                                array(
                                    'currency_code' => $item_details_arr['currencyCode'],
                                    'value' => $item_details_arr['itemValue'],
                                ),
                            'shipping' =>
                                array(
                                    'name' =>
                                        array(
                                            'full_name' => $billing_address_arr['Name'],
                                        ),
                                    'address' =>
                                        array(
                                            'address_line_1' => $billing_address_arr['address'],
                                            'admin_area_2' => $billing_address_arr['address'],
                                            'admin_area_1' => $billing_address_arr['address'],
                                            'postal_code' => $billing_address_arr['address'],
                                            'country_code' => 'US',
                                        ),
                                ),
                        ),
                ),
        );

        try {
                $client = new PayPalHttpClient($environment);
                $response = $client->execute($request);
                if ($response)
                {
                    $paypal_orderid = $response->result->id;
                    Session::put('paypalorderid', $paypal_orderid);
                    return $response->result->links[1]->href;
                }

                }catch(HttpException $exception) {
                    // Handle and store the error in the database
                    $errorDetails = json_decode($exception->getMessage(), true);
                    $error_details_json =json_encode($errorDetails);
                    return $redirect_urls_arr['cancel'];
                }

    }

    public function paymentSuccessPage()
    {
        session()->flush();

        return view('paymentsuccess');
    }

    public function paymentFailurePage()
    {
        session()->flush();
        return view('paymentfailure');
    
        
    }
}
