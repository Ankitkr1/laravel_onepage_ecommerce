   
<?php $__env->startSection('content'); ?>
<div class="red-status transform-size">
    <img width="444px" height="444px" src="<?php echo asset('images/failed.webp'); ?>" alt="#" />
    <p>OOPS! Payment Failed!.</p>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/webmantra/resources/views/paymentfailure.blade.php ENDPATH**/ ?>