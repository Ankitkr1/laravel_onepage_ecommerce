   
<?php $__env->startSection('content'); ?>
    
<div class="green-status transform-size">
    <img width="444px" height="444px" src="<?php echo asset('images/success.png'); ?>" alt="#" />
    <p>Thank You! Your payment was successful.</p>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/webmantra/resources/views/paymentsuccess.blade.php ENDPATH**/ ?>