@extends('layout')
   
@section('content')
    
<div class="green-status transform-size">
    <img width="444px" height="444px" src="{!! asset('images/success.png') !!}" alt="#" />
    <p>Thank You! Your payment was successful.</p>
</div>
    
@endsection