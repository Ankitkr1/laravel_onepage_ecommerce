@extends('layout')
   
@section('content')
<div class="red-status transform-size">
    <img width="444px" height="444px" src="{!! asset('images/failed.webp') !!}" alt="#" />
    <p>OOPS! Payment Failed!.</p>
    </div>
</div>
    
@endsection