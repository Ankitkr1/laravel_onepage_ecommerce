<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $products = [
            [
                'name' => 'Golden Money Plant',
                'description' => 'Good Luck Indoor plant Golden Money plant',
                'image' => '/images/01.jpg',
                'price' => 400
            ],
            [
                'name' => 'Golden Money Plant ',
                'description' => 'Good Luck Indoor  Golden Money plant',
                'image' => '/images/02.jpg',
                'price' => 350
            ],
            [
                'name' => 'Golden Zade Plant',
                'description' => 'Good Luck Indoor Golden Zade plant',
                'image' => '/images/07.jpg',
                'price' => 300
            ],
            [
                'name' => 'Green Money Plant',
                'description' => 'Good Luck Indoor Green Money plant',
                'image' => '/images/05.jpg',
                'price' => 700
            ],
            [
                'name' => 'Good luck Plant Combo',
                'description' => 'Good Luck Indoor plant combo',
                'image' => '/images/02.jpg',
                'price' => 400
            ],
            [
                'name' => 'Good luck Plant Combo',
                'description' => 'Good Luck Indoor plant combo',
                'image' => '/images/green.jpg',
                'price' => 800
            ]
            
        ];
  
        foreach ($products as $key => $value) {
            Product::create($value);
        }
        
    }
}
